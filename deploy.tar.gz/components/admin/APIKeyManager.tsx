'use client'
export default function APIKeyManager() {
  return <div className="p-4 border rounded"><p>APIKeyManager component</p></div>
}
