'use client'
export default function APIRateLimiting() {
  return <div className="p-4 border rounded"><p>APIRateLimiting component</p></div>
}
