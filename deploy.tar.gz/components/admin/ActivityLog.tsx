'use client'
export default function ActivityLog() {
  return <div className="p-4 border rounded"><p>ActivityLog component</p></div>
}
