'use client'
export default function AmenityManager() {
  return <div className="p-4 border rounded"><p>AmenityManager component</p></div>
}
