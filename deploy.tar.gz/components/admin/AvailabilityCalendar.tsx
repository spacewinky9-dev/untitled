'use client'
export default function AvailabilityCalendar() {
  return <div className="p-4 border rounded"><p>AvailabilityCalendar component</p></div>
}
