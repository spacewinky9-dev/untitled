'use client'
export default function BookingConfirmation() {
  return <div className="p-4 border rounded"><p>BookingConfirmation component</p></div>
}
