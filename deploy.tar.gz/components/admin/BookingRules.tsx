'use client'
export default function BookingRules() {
  return <div className="p-4 border rounded"><p>BookingRules component</p></div>
}
