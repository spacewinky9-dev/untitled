'use client'
export default function CAPTCHAIntegration() {
  return <div className="p-4 border rounded"><p>CAPTCHAIntegration component</p></div>
}
