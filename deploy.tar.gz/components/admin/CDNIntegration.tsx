'use client'
export default function CDNIntegration() {
  return <div className="p-4 border rounded"><p>CDNIntegration component</p></div>
}
