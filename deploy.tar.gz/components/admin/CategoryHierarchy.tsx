'use client'
export default function CategoryHierarchy() {
  return <div className="p-4 border rounded"><p>CategoryHierarchy component</p></div>
}
