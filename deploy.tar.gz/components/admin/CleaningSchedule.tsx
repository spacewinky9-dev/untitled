'use client'
export default function CleaningSchedule() {
  return <div className="p-4 border rounded"><p>CleaningSchedule component</p></div>
}
