'use client'
export default function ComparisonReports() {
  return <div className="p-4 border rounded"><p>ComparisonReports component</p></div>
}
