'use client'
export default function ContentScheduler() {
  return <div className="p-4 border rounded"><p>ContentScheduler component</p></div>
}
