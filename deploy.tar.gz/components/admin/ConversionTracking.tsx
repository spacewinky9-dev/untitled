'use client'
export default function ConversionTracking() {
  return <div className="p-4 border rounded"><p>ConversionTracking component</p></div>
}
