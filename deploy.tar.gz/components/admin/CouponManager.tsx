'use client'
import { Percent } from 'lucide-react'
export default function CouponManager() {
  return <div className="p-4 border rounded"><Percent className="h-6 w-6" /><p>Coupon management</p></div>
}
