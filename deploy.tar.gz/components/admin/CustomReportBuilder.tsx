'use client'
export default function CustomReportBuilder() {
  return <div className="p-4 border rounded"><p>CustomReportBuilder component</p></div>
}
