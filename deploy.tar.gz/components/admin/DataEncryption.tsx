'use client'
export default function DataEncryption() {
  return <div className="p-4 border rounded"><p>DataEncryption component</p></div>
}
