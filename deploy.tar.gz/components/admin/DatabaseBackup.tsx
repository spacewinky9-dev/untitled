'use client'
export default function DatabaseBackup() {
  return <div className="p-4 border rounded"><p>DatabaseBackup component</p></div>
}
