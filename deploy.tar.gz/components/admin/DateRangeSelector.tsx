'use client'
export default function DateRangeSelector() {
  return <div className="p-4 border rounded"><p>DateRangeSelector component</p></div>
}
