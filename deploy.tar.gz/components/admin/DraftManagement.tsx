'use client'
export default function DraftManagement() {
  return <div className="p-4 border rounded"><p>DraftManagement component</p></div>
}
