'use client'
export default function DragDropDashboard() {
  return <div className="p-4 border rounded"><p>DragDropDashboard component</p></div>
}
