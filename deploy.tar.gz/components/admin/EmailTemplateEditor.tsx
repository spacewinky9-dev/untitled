'use client'
export default function EmailTemplateEditor() {
  return <div className="p-4 border rounded"><p>EmailTemplateEditor component</p></div>
}
