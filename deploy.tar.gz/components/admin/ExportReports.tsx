'use client'
export default function ExportReports() {
  return <div className="p-4 border rounded"><p>ExportReports component</p></div>
}
