'use client'
export default function Favorites() {
  return <div className="p-4 border rounded"><p>Favorites component</p></div>
}
