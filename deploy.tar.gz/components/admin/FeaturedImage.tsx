'use client'
export default function FeaturedImage() {
  return <div className="p-4 border rounded"><p>FeaturedImage component</p></div>
}
