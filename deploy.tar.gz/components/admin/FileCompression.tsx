'use client'
export default function FileCompression() {
  return <div className="p-4 border rounded"><p>FileCompression component</p></div>
}
