'use client'
export default function GalleryCreator() {
  return <div className="p-4 border rounded"><p>GalleryCreator component</p></div>
}
