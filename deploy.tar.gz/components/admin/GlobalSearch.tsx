'use client'
export default function GlobalSearch() {
  return <div className="p-4 border rounded"><p>GlobalSearch component</p></div>
}
