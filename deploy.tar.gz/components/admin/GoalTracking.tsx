'use client'
export default function GoalTracking() {
  return <div className="p-4 border rounded"><p>GoalTracking component</p></div>
}
