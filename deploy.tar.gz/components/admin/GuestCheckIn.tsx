'use client'
export default function GuestCheckIn() {
  return <div className="p-4 border rounded"><p>GuestCheckIn component</p></div>
}
