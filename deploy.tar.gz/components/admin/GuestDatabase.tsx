'use client'
export default function GuestDatabase() {
  return <div className="p-4 border rounded"><p>GuestDatabase component</p></div>
}
