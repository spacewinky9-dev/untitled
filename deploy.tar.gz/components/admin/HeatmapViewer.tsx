'use client'
export default function HeatmapViewer() {
  return <div className="p-4 border rounded"><p>HeatmapViewer component</p></div>
}
