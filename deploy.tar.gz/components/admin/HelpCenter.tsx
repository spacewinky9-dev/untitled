'use client'
export default function HelpCenter() {
  return <div className="p-4 border rounded"><p>HelpCenter component</p></div>
}
