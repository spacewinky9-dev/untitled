'use client'
export default function IPWhitelist() {
  return <div className="p-4 border rounded"><p>IPWhitelist component</p></div>
}
