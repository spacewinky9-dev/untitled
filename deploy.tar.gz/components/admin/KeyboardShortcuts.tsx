'use client'
export default function KeyboardShortcuts() {
  return <div className="p-4 border rounded"><p>KeyboardShortcuts component</p></div>
}
