'use client'
export default function LogViewer() {
  return <div className="p-4 border rounded"><p>LogViewer component</p></div>
}
