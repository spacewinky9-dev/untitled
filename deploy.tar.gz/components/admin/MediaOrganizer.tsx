'use client'
export default function MediaOrganizer() {
  return <div className="p-4 border rounded"><p>MediaOrganizer component</p></div>
}
