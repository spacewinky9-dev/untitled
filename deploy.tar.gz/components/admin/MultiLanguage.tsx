'use client'
export default function MultiLanguage() {
  return <div className="p-4 border rounded"><p>MultiLanguage component</p></div>
}
