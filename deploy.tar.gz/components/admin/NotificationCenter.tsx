'use client'
export default function NotificationCenter() {
  return <div className="p-4 border rounded"><p>NotificationCenter component</p></div>
}
