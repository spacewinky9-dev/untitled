'use client'
export default function OnboardingTutorial() {
  return <div className="p-4 border rounded"><p>OnboardingTutorial component</p></div>
}
