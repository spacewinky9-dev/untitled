'use client'
export default function PDFManager() {
  return <div className="p-4 border rounded"><p>PDFManager component</p></div>
}
