'use client'
export default function PerformanceMonitor() {
  return <div className="p-4 border rounded"><p>PerformanceMonitor component</p></div>
}
