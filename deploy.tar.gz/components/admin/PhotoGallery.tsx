'use client'
export default function PhotoGallery() {
  return <div className="p-4 border rounded"><p>PhotoGallery component</p></div>
}
