'use client'
export default function PluginManager() {
  return <div className="p-4 border rounded"><p>PluginManager component</p></div>
}
