'use client'
export default function PriceHistory() {
  return <div className="p-4 border rounded"><p>Price history chart</p></div>
}
