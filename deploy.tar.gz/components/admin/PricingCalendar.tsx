'use client'
export default function PricingCalendar() {
  return <div className="p-4 border rounded"><p>PricingCalendar component</p></div>
}
