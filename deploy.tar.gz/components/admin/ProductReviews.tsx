'use client'
import { Star } from 'lucide-react'
export default function ProductReviews() {
  return <div className="p-4 border rounded"><Star className="h-6 w-6 text-yellow-500" /><p>Reviews management component</p></div>
}
