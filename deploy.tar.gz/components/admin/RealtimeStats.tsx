'use client'
export default function RealtimeStats() {
  return <div className="p-4 border rounded"><p>RealtimeStats component</p></div>
}
