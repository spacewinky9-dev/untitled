'use client'
export default function RefundProcessing() {
  return <div className="p-4 border rounded"><p>Refund processing system</p></div>
}
