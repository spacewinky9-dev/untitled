'use client'
export default function RelatedProducts() {
  return <div className="p-4 border rounded"><p>Related products selector</p></div>
}
