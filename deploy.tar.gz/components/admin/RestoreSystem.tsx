'use client'
export default function RestoreSystem() {
  return <div className="p-4 border rounded"><p>RestoreSystem component</p></div>
}
