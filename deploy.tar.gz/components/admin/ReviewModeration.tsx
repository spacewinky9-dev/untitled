'use client'
export default function ReviewModeration() {
  return <div className="p-4 border rounded"><p>ReviewModeration component</p></div>
}
