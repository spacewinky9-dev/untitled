'use client'
export default function RichTextEditor() {
  return <div className="p-4 border rounded"><p>RichTextEditor component</p></div>
}
