'use client'
export default function RoomTypes() {
  return <div className="p-4 border rounded"><p>RoomTypes component</p></div>
}
