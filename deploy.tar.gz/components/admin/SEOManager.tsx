'use client'
export default function SEOManager() {
  return <div className="p-4 border rounded"><p>SEOManager component</p></div>
}
