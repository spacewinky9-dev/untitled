'use client'
export default function SSLMonitor() {
  return <div className="p-4 border rounded"><p>SSLMonitor component</p></div>
}
