'use client'
export default function SalesDashboard() {
  return <div className="p-4 border rounded"><p>SalesDashboard component</p></div>
}
