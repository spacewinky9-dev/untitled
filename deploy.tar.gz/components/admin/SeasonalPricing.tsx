'use client'
export default function SeasonalPricing() {
  return <div className="p-4 border rounded"><p>SeasonalPricing component</p></div>
}
