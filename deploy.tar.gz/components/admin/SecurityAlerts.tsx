'use client'
export default function SecurityAlerts() {
  return <div className="p-4 border rounded"><p>SecurityAlerts component</p></div>
}
