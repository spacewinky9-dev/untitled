'use client'
export default function SecurityScanner() {
  return <div className="p-4 border rounded"><p>SecurityScanner component</p></div>
}
