'use client'
export default function TagManager() {
  return <div className="p-4 border rounded"><p>TagManager component</p></div>
}
