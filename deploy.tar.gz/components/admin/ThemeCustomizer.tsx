'use client'
export default function ThemeCustomizer() {
  return <div className="p-4 border rounded"><p>ThemeCustomizer component</p></div>
}
