'use client'
export default function TourInclusions() {
  return <div className="p-4 border rounded"><p>TourInclusions component</p></div>
}
