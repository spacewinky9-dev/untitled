'use client'
export default function TourItinerary() {
  return <div className="p-4 border rounded"><p>TourItinerary component</p></div>
}
