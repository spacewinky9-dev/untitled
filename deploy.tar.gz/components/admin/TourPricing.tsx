'use client'
export default function TourPricing() {
  return <div className="p-4 border rounded"><p>TourPricing component</p></div>
}
