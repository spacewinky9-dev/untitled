'use client'
export default function TrafficAnalytics() {
  return <div className="p-4 border rounded"><p>TrafficAnalytics component</p></div>
}
