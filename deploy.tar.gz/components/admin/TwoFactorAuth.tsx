'use client'
export default function TwoFactorAuth() {
  return <div className="p-4 border rounded"><p>TwoFactorAuth component</p></div>
}
