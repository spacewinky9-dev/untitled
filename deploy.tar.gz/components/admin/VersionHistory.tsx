'use client'
export default function VersionHistory() {
  return <div className="p-4 border rounded"><p>VersionHistory component</p></div>
}
