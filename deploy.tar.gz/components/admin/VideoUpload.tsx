'use client'
export default function VideoUpload() {
  return <div className="p-4 border rounded"><p>VideoUpload component</p></div>
}
