'use client'
export default function WebhookManager() {
  return <div className="p-4 border rounded"><p>WebhookManager component</p></div>
}
