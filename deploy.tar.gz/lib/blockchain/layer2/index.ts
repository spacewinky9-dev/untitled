export { Layer2Scaling, OptimisticRollup, ZKRollup, StateChannel, type RollupBatch, type RollupType, type FraudProof } from './Layer2Scaling';
