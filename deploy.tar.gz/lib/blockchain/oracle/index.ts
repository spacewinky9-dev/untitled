export { DecentralizedOracleNetwork } from './OracleNetwork';
